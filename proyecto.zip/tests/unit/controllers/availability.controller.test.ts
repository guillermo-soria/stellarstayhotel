import { getAvailableRoomsController } from '../../../src/adapters/http/controllers/availability.controller';
import { Request, Response, NextFunction } from 'express';

// Mock the external dependencies
jest.mock('../../../src/infrastructure/repositories/in-memory-room.repository');
jest.mock('../../../src/application/use-cases/get-available-rooms');

// Extend Request interface to include validatedQuery
interface MockRequest extends Partial<Request> {
  validatedQuery?: any;
}

describe('getAvailableRoomsController', () => {
  let mockRequest: MockRequest;
  let mockResponse: Partial<Response>;
  let mockNext: NextFunction;

  beforeEach(() => {
    mockRequest = {
      validatedQuery: {
        checkIn: new Date('2024-12-01'),
        checkOut: new Date('2024-12-03'),
        guests: 2,
        breakfast: false,
        breakdown: false
      }
    };
    
    mockResponse = {
      json: jest.fn().mockReturnThis(),
      status: jest.fn().mockReturnThis()
    };

    mockNext = jest.fn();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should return available rooms with correct format', async () => {
    // Mock the GetAvailableRooms use case to return sample data
    const mockRooms = [
      {
        roomId: 'r-101',
        type: 'junior',
        capacity: 2,
        baseRate: 6000,
        totalCents: 12000,
        priceCentsPerNight: 6000,
        nights: 2,
        breakdown: undefined
      }
    ];

    // Re-import and mock after setting up the mock
    const { GetAvailableRooms } = require('../../../src/application/use-cases/get-available-rooms');
    GetAvailableRooms.prototype.execute = jest.fn().mockResolvedValue(mockRooms);

    await getAvailableRoomsController(
      mockRequest as Request,
      mockResponse as Response,
      mockNext
    );

    expect(mockResponse.json).toHaveBeenCalledWith({
      items: [
        {
          roomId: 'r-101',
          type: 'junior',
          capacity: 2,
          baseRateCents: 6000,
          pricing: {
            totalCents: 12000,
            pricePerNightCents: 6000,
            nights: 2,
            currency: 'USD',
            breakdown: undefined
          }
        }
      ],
      paging: {
        limit: 20,
        nextCursor: null
      },
      query: {
        checkIn: mockRequest.validatedQuery!.checkIn,
        checkOut: mockRequest.validatedQuery!.checkOut,
        guests: 2,
        type: undefined,
        breakfast: false
      }
    });
  });

  it('should call next with error when use case throws', async () => {
    const error = new Error('Use case error');

    // Mock the use case to throw an error
    const { GetAvailableRooms } = require('../../../src/application/use-cases/get-available-rooms');
    GetAvailableRooms.prototype.execute = jest.fn().mockRejectedValue(error);

    await getAvailableRoomsController(
      mockRequest as Request,
      mockResponse as Response,
      mockNext
    );

    expect(mockNext).toHaveBeenCalledWith(error);
    expect(mockResponse.json).not.toHaveBeenCalled();
  });

  it('should pass correct parameters to use case', async () => {
    mockRequest.validatedQuery = {
      checkIn: new Date('2024-12-01'),
      checkOut: new Date('2024-12-05'),
      guests: 3,
      type: 'king',
      breakfast: true,
      breakdown: true
    };

    const { GetAvailableRooms } = require('../../../src/application/use-cases/get-available-rooms');
    const mockExecute = jest.fn().mockResolvedValue([]);
    GetAvailableRooms.prototype.execute = mockExecute;

    await getAvailableRoomsController(
      mockRequest as Request,
      mockResponse as Response,
      mockNext
    );

    expect(mockExecute).toHaveBeenCalledWith({
      dateRange: {
        checkIn: new Date('2024-12-01'),
        checkOut: new Date('2024-12-05')
      },
      guests: 3,
      type: 'king',
      breakfast: true,
      includeBreakdown: true
    });
  });

  it('should handle rooms with breakdown data', async () => {
    const mockRooms = [
      {
        roomId: 'r-201',
        type: 'king',
        capacity: 3,
        baseRate: 9000,
        totalCents: 22500,
        priceCentsPerNight: 11250,
        nights: 2,
        breakdown: {
          basePrice: 18000,
          weekendUplift: 4500,
          lengthDiscount: 0,
          breakfast: 0
        }
      }
    ];

    const { GetAvailableRooms } = require('../../../src/application/use-cases/get-available-rooms');
    GetAvailableRooms.prototype.execute = jest.fn().mockResolvedValue(mockRooms);

    await getAvailableRoomsController(
      mockRequest as Request,
      mockResponse as Response,
      mockNext
    );

    expect(mockResponse.json).toHaveBeenCalledWith(
      expect.objectContaining({
        items: [
          expect.objectContaining({
            roomId: 'r-201',
            type: 'king',
            pricing: expect.objectContaining({
              breakdown: {
                basePrice: 18000,
                weekendUplift: 4500,
                lengthDiscount: 0,
                breakfast: 0
              }
            })
          })
        ]
      })
    );
  });
});
